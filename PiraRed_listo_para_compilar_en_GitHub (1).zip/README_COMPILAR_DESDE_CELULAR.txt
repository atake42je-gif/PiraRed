PIRARED - COMPILAR APK DESDE EL CELULAR

Este ZIP incluye el proyecto Android y un flujo de GitHub Actions para compilar una APK de prueba en la nube.

PASOS:
1. Descarga y descomprime este ZIP en el celular.
2. Entra en https://github.com e inicia sesión o crea una cuenta.
3. Crea un repositorio nuevo llamado PiraRed (puede ser privado).
4. En el repositorio, usa Add file > Upload files y sube TODO el contenido descomprimido, incluida la carpeta oculta .github/workflows. Si el navegador no permite subir carpetas, activa “Sitio para computadoras” o usa la subida web de GitHub desde un navegador de escritorio.
5. Confirma los archivos con Commit changes.
6. Abre la pestaña Actions del repositorio. Si aparece una confirmación para habilitar workflows, aceptala.
7. En “Compilar PiraRed APK”, toca Run workflow y luego el botón verde Run workflow.
8. Espera a que termine en verde. Abre esa ejecución, baja a Artifacts y toca PiraRed-apk para descargar el ZIP con app-debug.apk.
9. Descomprime el ZIP descargado y toca app-debug.apk para instalar. Android podría pedir permiso para instalar apps desconocidas para el navegador o gestor de archivos.

IMPORTANTE:
- Esta es una APK de prueba/debug, no una versión firmada para publicar en Play Store.
- No compartas contraseñas ni códigos de verificación.
- Si falla la compilación, copia el error o manda una captura para revisar qué ocurrió.
